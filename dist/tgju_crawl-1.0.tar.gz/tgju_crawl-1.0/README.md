# Tgju_price_crawling
<left><img alt="Shows an illustrated sun in light mode and a moon with stars in dark mode." src="https://www.tgju.org/touch-icon-ipad.png">
</left>

In this task, I want to scrap data on tgju.org site. tgju a great site to get price data, especially the price of gold and its derivatives in Iran. I have used bs4 package for scraping.